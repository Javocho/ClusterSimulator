var searchData=
[
  ['posicion_54',['posicion',['../classProcesador.html#a75f87b50fb0356befde02636141ea08b',1,'Procesador']]],
  ['prioridad_5fcont_55',['Prioridad_cont',['../structArea__espera_1_1Prioridad__cont.html',1,'Area_espera']]],
  ['procesador_56',['Procesador',['../classProcesador.html',1,'Procesador'],['../classProcesador.html#a8fcdb116e68accc213610b95b50a07a5',1,'Procesador::Procesador(int mem)'],['../classProcesador.html#aacfa2a06c7d44636ecfb0338bebbfa8b',1,'Procesador::Procesador()']]],
  ['procesador_2ecc_57',['Procesador.cc',['../Procesador_8cc.html',1,'']]],
  ['procesador_2ehh_58',['Procesador.hh',['../Procesador_8hh.html',1,'']]],
  ['procesador_5fadecuado_59',['procesador_adecuado',['../classCluster.html#a9bb6a11775bc400e5772fb6fa25244dd',1,'Cluster']]],
  ['proceso_60',['Proceso',['../classProceso.html',1,'Proceso'],['../classProceso.html#a632f57d6ec48e76c80fbeb7734c1148c',1,'Proceso::Proceso()'],['../classProceso.html#aae36aa82451bb294e964a81d05d5371c',1,'Proceso::Proceso(int id, int mem, int time)']]],
  ['proceso_2ecc_61',['Proceso.cc',['../Proceso_8cc.html',1,'']]],
  ['proceso_2ehh_62',['Proceso.hh',['../Proceso_8hh.html',1,'']]],
  ['proceso_5fenviado_63',['proceso_enviado',['../classCluster.html#a122e01e92292e7fc7ed6dedf03d9f89c',1,'Cluster']]],
  ['procesos_64',['procesos',['../classProcesador.html#a09415bd25560d91d36cbb2238f557d45',1,'Procesador']]],
  ['program_2ecc_65',['program.cc',['../program_8cc.html',1,'']]],
  ['práctica_20pro2_2e_20simulador_20de_20un_20cluster_20de_20procesadores_20multiproceso_2e_66',['Práctica PRO2. Simulador de un cluster de procesadores multiproceso.',['../index.html',1,'']]]
];
