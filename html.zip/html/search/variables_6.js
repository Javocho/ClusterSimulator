var searchData=
[
  ['posicion_138',['posicion',['../classProcesador.html#a75f87b50fb0356befde02636141ea08b',1,'Procesador']]],
  ['procesos_139',['procesos',['../classProcesador.html#a09415bd25560d91d36cbb2238f557d45',1,'Procesador']]]
];
