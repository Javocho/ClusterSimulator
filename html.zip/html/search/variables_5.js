var searchData=
[
  ['num_5faceptados_136',['num_aceptados',['../structArea__espera_1_1Prioridad__cont.html#aa3c38f0f932019a4ab1698357e8fd729',1,'Area_espera::Prioridad_cont']]],
  ['num_5frechazados_137',['num_rechazados',['../structArea__espera_1_1Prioridad__cont.html#a480cc7ee9a3bd6bacf15381540251b92',1,'Area_espera::Prioridad_cont']]]
];
