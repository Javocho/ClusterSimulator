var searchData=
[
  ['prioridad_5fcont_72',['Prioridad_cont',['../structArea__espera_1_1Prioridad__cont.html',1,'Area_espera']]],
  ['procesador_73',['Procesador',['../classProcesador.html',1,'']]],
  ['proceso_74',['Proceso',['../classProceso.html',1,'']]]
];
