var searchData=
[
  ['hay_5fhueco_5fabajo_31',['hay_hueco_abajo',['../classProcesador.html#ac38e321e5b0f50865423653cc3769059',1,'Procesador']]],
  ['hay_5fhueco_5farriba_32',['hay_hueco_arriba',['../classProcesador.html#af7af47d9fa3f2dd08188b3439cfb3d77',1,'Procesador']]],
  ['hay_5fprocesos_33',['hay_procesos',['../classProcesador.html#a345ff9bc5ca6c4f92f00dd622a83bf08',1,'Procesador']]],
  ['hueco_5fajustado_34',['hueco_ajustado',['../classProcesador.html#a3e90becacf3ce1fedc2a89d382ec56a2',1,'Procesador']]],
  ['huecos_35',['huecos',['../classProcesador.html#aed1c812831f1e3d17067b205863defe6',1,'Procesador']]]
];
