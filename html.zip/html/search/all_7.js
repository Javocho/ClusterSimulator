var searchData=
[
  ['main_46',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['mem_47',['mem',['../classProceso.html#a2f0077c9db56775d552dc3941a81ec0b',1,'Proceso']]],
  ['mem_5flibre_48',['mem_libre',['../classProcesador.html#a28fc36ca294d549b2b1f8f2db8d10386',1,'Procesador']]],
  ['memtotal_49',['memtotal',['../classProcesador.html#a43d151a3b26c66c7198b5026e29a19f9',1,'Procesador']]],
  ['modificar_5fcluster_50',['modificar_cluster',['../classCluster.html#afe5873508fd1b91043db38c18b56e08c',1,'Cluster']]]
];
