var searchData=
[
  ['huecos_131',['huecos',['../classProcesador.html#aed1c812831f1e3d17067b205863defe6',1,'Procesador']]]
];
