var searchData=
[
  ['cluster_5fmap_127',['cluster_map',['../classCluster.html#afc792da09923d9f60361632f36a3b717',1,'Cluster']]],
  ['cluster_5ftree_128',['cluster_tree',['../classCluster.html#a8ae4e3f2a925b3f03b619785678ca748',1,'Cluster']]],
  ['cola_5fprocesos_129',['cola_procesos',['../structArea__espera_1_1Prioridad__cont.html#a5b5c2492dad74a5d3b8e3d3368d267c0',1,'Area_espera::Prioridad_cont']]]
];
