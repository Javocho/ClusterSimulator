var searchData=
[
  ['get_5fcluster_5ftree_26',['get_cluster_tree',['../classCluster.html#a69f6a7ac8204853f53f81f99bf6c60da',1,'Cluster']]],
  ['get_5fid_27',['get_id',['../classProceso.html#af2d7b179495f47a5f3b71bd34d1941c5',1,'Proceso']]],
  ['get_5fmem_28',['get_mem',['../classProceso.html#a9232d18bcb134974f1c75af741b09035',1,'Proceso']]],
  ['get_5fmem_5flibre_29',['get_mem_libre',['../classProcesador.html#ae673faef50e26185e54cdc2a7c458f03',1,'Procesador']]],
  ['get_5ftime_30',['get_time',['../classProceso.html#a6b2a6733de44fac7cec0f8c209c01640',1,'Proceso']]]
];
