var searchData=
[
  ['enviar_5fprocesos_5fcluster_22',['enviar_procesos_cluster',['../classArea__espera.html#abe39b416f75bcd2d4eb0e1e3e17732d5',1,'Area_espera']]],
  ['espera_23',['espera',['../classArea__espera.html#a4a316f0af4c823f9873bd947e31dc86a',1,'Area_espera']]],
  ['existe_5fprocesador_24',['existe_procesador',['../classCluster.html#a00c7c6cee7ff9b2d4eac94f08162e55c',1,'Cluster']]],
  ['existe_5fproceso_25',['existe_proceso',['../classArea__espera.html#a0e523c8dcffa6a791621317184bf7e7d',1,'Area_espera::existe_proceso()'],['../classProcesador.html#ace943a1ef54559dcb81318ac7fada4b6',1,'Procesador::existe_proceso()']]]
];
