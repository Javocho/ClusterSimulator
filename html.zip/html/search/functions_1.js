var searchData=
[
  ['baja_5fprioridad_90',['baja_prioridad',['../classArea__espera.html#a7401296748ebe4074beb1720783ab85d',1,'Area_espera']]],
  ['baja_5fproceso_91',['baja_proceso',['../classProcesador.html#ad9e5d25745595f9f503de203a970a4a2',1,'Procesador']]],
  ['baja_5fproceso_5fprocesador_92',['baja_proceso_procesador',['../classCluster.html#a223728a9bc84076c716e13540f9ed299',1,'Cluster']]]
];
