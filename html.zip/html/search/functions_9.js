var searchData=
[
  ['procesador_122',['Procesador',['../classProcesador.html#aacfa2a06c7d44636ecfb0338bebbfa8b',1,'Procesador::Procesador()'],['../classProcesador.html#a8fcdb116e68accc213610b95b50a07a5',1,'Procesador::Procesador(int mem)']]],
  ['procesador_5fadecuado_123',['procesador_adecuado',['../classCluster.html#a9bb6a11775bc400e5772fb6fa25244dd',1,'Cluster']]],
  ['proceso_124',['Proceso',['../classProceso.html#a632f57d6ec48e76c80fbeb7734c1148c',1,'Proceso::Proceso()'],['../classProceso.html#aae36aa82451bb294e964a81d05d5371c',1,'Proceso::Proceso(int id, int mem, int time)']]],
  ['proceso_5fenviado_125',['proceso_enviado',['../classCluster.html#a122e01e92292e7fc7ed6dedf03d9f89c',1,'Cluster']]]
];
