var searchData=
[
  ['set_5ftime_126',['set_time',['../classProceso.html#a9cc227325f7cf9220b8372022d9fd827',1,'Proceso']]]
];
