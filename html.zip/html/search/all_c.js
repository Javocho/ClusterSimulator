var searchData=
[
  ['time_68',['time',['../classProceso.html#adf0f9027bbbb8f0c102a48376e5ef016',1,'Proceso']]]
];
