var searchData=
[
  ['alta_5fprioridad_84',['alta_prioridad',['../classArea__espera.html#aa14670db4ca5a1fcfd5ef71e4e6950f0',1,'Area_espera']]],
  ['alta_5fproceso_85',['alta_proceso',['../classProcesador.html#a9d904c8ea6f4c5a069c24851afb6da4c',1,'Procesador']]],
  ['alta_5fproceso_5fespera_86',['alta_proceso_espera',['../classArea__espera.html#a320c099eb902755dd2cff657a5592a5d',1,'Area_espera']]],
  ['alta_5fproceso_5fprocesador_87',['alta_proceso_procesador',['../classCluster.html#ad89610eceb8200c17ed19d87705b5d5f',1,'Cluster']]],
  ['area_5fespera_88',['Area_espera',['../classArea__espera.html#a03fae0938ad34fe4e0ea6e0d0b0852b8',1,'Area_espera']]],
  ['avanzar_5ftiempo_89',['avanzar_tiempo',['../classCluster.html#a60fe695fb3a3ee656f97541efc6ac41a',1,'Cluster::avanzar_tiempo()'],['../classProcesador.html#aa13775c00d510ff83cccbe99bcf22c7b',1,'Procesador::avanzar_tiempo()']]]
];
