var searchData=
[
  ['cluster_70',['Cluster',['../classCluster.html',1,'']]],
  ['comparepairs_71',['ComparePairs',['../structProcesador_1_1ComparePairs.html',1,'Procesador']]]
];
