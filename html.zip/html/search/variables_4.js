var searchData=
[
  ['mem_133',['mem',['../classProceso.html#a2f0077c9db56775d552dc3941a81ec0b',1,'Proceso']]],
  ['mem_5flibre_134',['mem_libre',['../classProcesador.html#a28fc36ca294d549b2b1f8f2db8d10386',1,'Procesador']]],
  ['memtotal_135',['memtotal',['../classProcesador.html#a43d151a3b26c66c7198b5026e29a19f9',1,'Procesador']]]
];
