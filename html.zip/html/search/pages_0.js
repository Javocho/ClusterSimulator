var searchData=
[
  ['práctica_20pro2_2e_20simulador_20de_20un_20cluster_20de_20procesadores_20multiproceso_2e_141',['Práctica PRO2. Simulador de un cluster de procesadores multiproceso.',['../index.html',1,'']]]
];
