var searchData=
[
  ['i_5fconfigurar_5fcluster_110',['i_configurar_cluster',['../classCluster.html#a5df8b8b107d305be1ae4a542971bac69',1,'Cluster']]],
  ['i_5fmodificar_5fcluster_111',['i_modificar_cluster',['../classCluster.html#a3a555254001f09721d9e6205378fab4f',1,'Cluster']]],
  ['i_5fprocesador_5fadecuado_112',['i_procesador_adecuado',['../classCluster.html#a9b2d9f834c3f882ef66a4599ab7d28b4',1,'Cluster']]],
  ['imprimir_113',['imprimir',['../classProcesador.html#a982d63719a2883f9e2a5191301441897',1,'Procesador']]],
  ['imprimir_5farea_5fespera_114',['imprimir_area_espera',['../classArea__espera.html#a030a4d4d0bcdceddcfdb15403a92c865',1,'Area_espera']]],
  ['imprimir_5festructura_5fcluster_115',['imprimir_estructura_cluster',['../classCluster.html#ab24996056d8c5a12b7acd84ea843728e',1,'Cluster']]],
  ['imprimir_5fprioridad_116',['imprimir_prioridad',['../classArea__espera.html#a100ce44b11c72f77d145da98ebb7d664',1,'Area_espera']]],
  ['imprimir_5fprocesador_117',['imprimir_procesador',['../classCluster.html#a2328f9b39ff9fc1a9564cb447fa7bd88',1,'Cluster']]],
  ['imprimir_5fprocesadores_5fcluster_118',['imprimir_procesadores_cluster',['../classCluster.html#a9436d5be8c89c3c09e69b2ccebc7cff0',1,'Cluster']]]
];
