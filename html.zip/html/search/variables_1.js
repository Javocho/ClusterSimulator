var searchData=
[
  ['espera_130',['espera',['../classArea__espera.html#a4a316f0af4c823f9873bd947e31dc86a',1,'Area_espera']]]
];
